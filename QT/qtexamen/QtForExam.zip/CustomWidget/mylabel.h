#ifndef MYLABEL_H
#define MYLABEL_H

#include <QWidget>

class MyLabel : public QLabel
{
public:
    MyLabel();
    ~MyLabel();
};

#endif // MYLABEL_H
