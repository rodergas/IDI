#include "mylabel.h"

MyLabel::MyLabel()
{

}

MyLabel::~MyLabel()
{

}

